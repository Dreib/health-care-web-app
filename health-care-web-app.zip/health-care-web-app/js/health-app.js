function makeAppointment() {
    document.getElementById('makeAppointment').style.display = 'block';
    document.getElementById('ccm').style.display = 'none';
    document.getElementById('bt').style.display = 'none';
    document.getElementById('addPerson').style.display = 'none';
    document.getElementById('showPerson').style.display = 'none';
    document.getElementById('showAppointments').style.display = 'none';
    document.getElementById('showBt').style.display = 'none';
    document.getElementById('showCcm').style.display = 'none';
    document.getElementById('home').style.display = 'none';
}

function ccm() {
    document.getElementById('makeAppointment').style.display = 'none';
    document.getElementById('ccm').style.display = 'block';
    document.getElementById('bt').style.display = 'none';
    document.getElementById('addPerson').style.display = 'none';
    document.getElementById('showPerson').style.display = 'none';
    document.getElementById('showAppointments').style.display = 'none';
    document.getElementById('showBt').style.display = 'none';
    document.getElementById('showCcm').style.display = 'none';
    document.getElementById('home').style.display = 'none';
}

function bt() {
    document.getElementById('makeAppointment').style.display = 'none';
    document.getElementById('ccm').style.display = 'none';
    document.getElementById('bt').style.display = 'block';
    document.getElementById('addPerson').style.display = 'none';
    document.getElementById('showPerson').style.display = 'none';
    document.getElementById('showAppointments').style.display = 'none';
    document.getElementById('showBt').style.display = 'none';
    document.getElementById('showCcm').style.display = 'none';
    document.getElementById('home').style.display = 'none';
}

function addPerson() {
    document.getElementById('makeAppointment').style.display = 'none';
    document.getElementById('ccm').style.display = 'none';
    document.getElementById('bt').style.display = 'none';
    document.getElementById('addPerson').style.display = 'block';
    document.getElementById('home').style.display = 'none';
    document.getElementById('showPerson').style.display = 'none';
    document.getElementById('showAppointments').style.display = 'none';
    document.getElementById('showBt').style.display = 'none';
    document.getElementById('showCcm').style.display = 'none';
}

function postPerson() {
            const cnp = $("#cnp").val();
            const nume = $("#nume").val();
            const prenume = $("#prenume").val();
            const judet = $("#judet").val();
            const localitate = $("#loc").val();
            const strada = $("#strada").val();
            const numar = $("#numar").val();
            const bloc = $("#bloc").val();
            const etaj = $("#etaj").val();
            const ap = $("#ap").val();
            const tip = $("#tip").val();

            const objModel = {
                cnp: cnp, nume: nume, prenume: prenume, judet: judet, localitate: localitate,
                strada: strada, numar: numar, bloc: bloc, etaj: etaj, apartament: ap, tip: tip
            };

            $.ajax({
                type: "POST",
                url: "http://localhost:8085/persoana",
                headers: {"Content-Type" : "application/json",
                          "Accept" : "application/json"},
                dataType: 'json',
                data: JSON.stringify(objModel),
            });
}

function postAppointment() {
    const cnp = $('#cnp_app').val();
    const data = $('#date_app').val();
    const ora = $('#time_app').val();
    const observatie = $('#observatie').val();

    const objModel = {personcnp: cnp, data: data, ora: ora, observatie: observatie,};

    $.ajax({
        type: "POST",
        url: "http://localhost:8085/programari",
        headers: {"Content-Type" : "application/json",
            "Accept" : "application/json"},
        dataType: 'json',
        data: JSON.stringify(objModel)
    })
}

function postBt() {
    const cnp = $('#cnp_bt').val();
    const data = $('#data_bt').val();
    const judet = $('#judet_bt').val();
    const localitate = $('#loc_bt').val();
    const unitate = $('#us_bt').val();
    const catre = $('#to_bt').val();
    const diagnostic = $('#dp_bt').val();
    const motiv = $('#mt_bt').val();
    const inv = $('#it_bt').val();

    const objModel = {cnp: cnp, trimitere: data, judet: judet, localitate: localitate,
            unitate: unitate, catre: catre, diagnostic: diagnostic,
            motiv: motiv, investigatii: inv};

    $.ajax({
        type: "POST",
        url: "http://localhost:8085/bt",
        headers: {"Content-Type" : "application/json",
            "Accept" : "application/json"},
        dataType: 'json',
        data: JSON.stringify(objModel)
    })

}

function postCcm() {
    const cnp = $('#cnp_ccm').val();
    const serie = $('#serie').val();
    const numar = $('#nr_ccm').val();
    const vds = $('#vds_ccm').val();
    const vde = $('#vde_ccm').val();

    const objModel = {cnp: cnp, serie: serie, numar: numar, v_date_start: vds,
        v_date_end: vde};

    $.ajax({
        type: "POST",
        url: "http://localhost:8085/ccm",
        headers: {"Content-Type" : "application/json",
            "Accept" : "application/json"},
        dataType: 'json',
        data: JSON.stringify(objModel)
    })
}

function displayPerson() {
    document.getElementById('makeAppointment').style.display = 'none';
    document.getElementById('ccm').style.display = 'none';
    document.getElementById('bt').style.display = 'none';
    document.getElementById('addPerson').style.display = 'none';
    document.getElementById('home').style.display = 'none';
    document.getElementById('showPerson').style.display = 'block';
    document.getElementById('showAppointments').style.display = 'none';
    document.getElementById('showBt').style.display = 'none';
    document.getElementById('showCcm').style.display = 'none';

    $.ajax({
        url: "http://localhost:8085/persoana/",
        type: "GET",
        dataType: "JSON",
        success: function (data) {
            $('#show-person').dataTable({
                "data": data,
                "columns": [
                    {data: 'cnp'},
                    {data: 'nume'},
                    {data: 'prenume'},
                    {data: 'judet'},
                    {data: 'localitate'},
                    {data: 'strada'},
                    {data: 'numar'},
                    {data: 'bloc'},
                    {data: 'etaj'},
                    {data: 'apartament'},
                    {data: 'tip'},
                    {
                        data: null,
                        render: function (data, type, row, meta) {
                            return '<button class="btn btn-danger" onclick="deletePerson(' + data.cnp + ')">Delete</button>';
                        }
                    }
                ]
            });
        }
    })
}

function deletePerson(cnp) {
    $(document).ready(function () {
        $.ajax({
            type: "DELETE",
            url: "http://localhost:8085/persoana/" + cnp
        }).success(function() {
            alert("Delete successful.");
        })
    })
}

function displayAppointment() {
    document.getElementById('makeAppointment').style.display = 'none';
    document.getElementById('ccm').style.display = 'none';
    document.getElementById('bt').style.display = 'none';
    document.getElementById('addPerson').style.display = 'none';
    document.getElementById('home').style.display = 'none';
    document.getElementById('showPerson').style.display = 'none';
    document.getElementById('showAppointments').style.display = 'block';
    document.getElementById('showBt').style.display = 'none';
    document.getElementById('showCcm').style.display = 'none';

    $.ajax({
        url: "http://localhost:8085/programari/",
        type: "GET",
        dataType: "JSON",
        success: function (data) {
            $('#show-app').dataTable({
                "data": data,
                "columns": [
                    {data: 'id'},
                    {data: 'personcnp'},
                    {data: 'data'},
                    {data: 'ora'},
                    {data: 'observatie'},
                    {
                        data: null,
                        render: function (data, type, row, meta) {
                            return '<button class="btn btn-success" onclick="editAppointment(' + data.id + ')">Edit</button>';
                        }
                    },
                    {
                        data: null,
                        render: function (data, type, row, meta) {
                            return '<button class="btn btn-danger" onclick="deleteAppointment(' + data.id + ')">Delete</button>';
                        }
                    }
                ]
            });
        }
    })
}

function deleteAppointment(id) {
    $(document).ready(function () {
        $.ajax({
            type: "DELETE",
            url: "http://localhost:8085/programari/" + id
        }).success(function() {
            alert("Delete successful.");
        })
    })
}

function editAppointment(id) {
    $(document).ready(function () {
        $.ajax({
            type: "PUT",
            url: "http://localhost:8085/programari/" + id
        }).success(function() {
            alert("Edit successful.");
        })
    })
}

function displayBt() {
    document.getElementById('makeAppointment').style.display = 'none';
    document.getElementById('ccm').style.display = 'none';
    document.getElementById('bt').style.display = 'none';
    document.getElementById('addPerson').style.display = 'none';
    document.getElementById('home').style.display = 'none';
    document.getElementById('showPerson').style.display = 'none';
    document.getElementById('showAppointments').style.display = 'none';
    document.getElementById('showBt').style.display = 'block';
    document.getElementById('showCcm').style.display = 'none';

    $.ajax({
        url: "http://localhost:8085/bt/",
        type: "GET",
        dataType: "JSON",
        success: function (data) {
            $('#show-bt').dataTable({
                "data": data,
                "columns": [
                    {data: 'id'},
                    {data: 'trimitere'},
                    {data: 'judet'},
                    {data: 'localitate'},
                    {data: 'unitate'},
                    {data: 'cnp'},
                    {data: 'catre'},
                    {data: 'diagnostic'},
                    {data: 'motiv'},
                    {data: 'investigatii'},
                    {
                        data: null,
                        render: function (data, type, row, meta) {
                            return '<button class="btn btn-danger" onclick="deleteBt(' + data.id + ')">Delete</button>';
                        }
                    }
                ]
            });
        }
    })
}

function deleteBt(id) {
    $(document).ready(function () {
        $.ajax({
            type: "DELETE",
            url: "http://localhost:8085/bt/" + id
        }).success(function() {
            alert("Delete successful.");
        })
    })
}

function displayCcm() {
    document.getElementById('makeAppointment').style.display = 'none';
    document.getElementById('ccm').style.display = 'none';
    document.getElementById('bt').style.display = 'none';
    document.getElementById('addPerson').style.display = 'none';
    document.getElementById('home').style.display = 'none';
    document.getElementById('showPerson').style.display = 'none';
    document.getElementById('showAppointments').style.display = 'none';
    document.getElementById('showBt').style.display = 'none';
    document.getElementById('showCcm').style.display = 'block';

    $.ajax({
        url: "http://localhost:8085/ccm/",
        type: "GET",
        dataType: "JSON",
        success: function (data) {
            $('#show-ccm').dataTable({
                "data": data,
                "columns": [
                    {data: 'id'},
                    {data: 'serie'},
                    {data: 'numar'},
                    {data: 'v_date_start'},
                    {data: 'v_date_end'},
                    {data: 'cnp'},
                    {
                        data: null,
                        render: function (data, type, row, meta) {
                            return '<button class="btn btn-danger" onclick="deleteCcm(' + data.id + ')">Delete</button>';
                        }
                    }
                ]
            });
        }
    })
}

function deleteCcm(id) {
    $(document).ready(function () {
        $.ajax({
            type: "DELETE",
            url: "http://localhost:8085/ccm/" + id
        }).success(function() {
            alert("Delete successful.");
        })
    })
}